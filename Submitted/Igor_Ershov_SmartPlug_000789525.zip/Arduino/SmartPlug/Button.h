#ifndef __BTN__
#define __BTN__

class Button{
  public:
  virtual void begin();
  virtual bool isPressed();
};

#endif
